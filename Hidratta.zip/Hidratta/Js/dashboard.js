/* -------- Menu ------- */
$('nav ul li').click(function(){
$(this).addClass("active").siblings().removeClass("active");
});

/* ------ Botoes gerenciamento ----- */
$('.btn').click(function(){
$(this).addClass("active").siblings().removeClass("active");
});

$(".btn").submit(function(e){
	e.preventDefault();
});

//----------------------------------------------------

/*Display das sections*/

function principal(){
	document.getElementById("principal").style.display = "block";
	document.getElementById("adm-slides").style.display = "none";
	document.getElementById("adm-obras").style.display = "none";
	document.getElementById("adm-clientes").style.display = "none";
	document.getElementById("config").style.display = "none";
}

function adm(opc){

	document.getElementById("principal").style.display = "none";
	document.getElementById("config").style.display = "none";
	$('.btn').removeClass("active");
	
	switch(opc){
		//Section slides
		case 0:
			document.getElementById("adm-slides").style.display = "block";
			document.getElementById("adm-tabelas-existentes-slides").style.display = "block";
			document.getElementById("aux-adm-novos-slides").style.display = "none";
			
			document.getElementById("adm-clientes").style.display = "none";
			document.getElementById("adm-obras").style.display = "none";
			break;
		//Section obras
		case 1:
			document.getElementById("adm-obras").style.display = "block";
			document.getElementById("adm-tabelas-existentes-obras").style.display = "block";
			document.getElementById("aux-adm-novas-obras").style.display = "none";
			
			document.getElementById("adm-clientes").style.display = "none";
			document.getElementById("adm-slides").style.display = "none";
			break;
		//Section clientes
		case 2:
			document.getElementById("adm-clientes").style.display = "block";
			document.getElementById("adm-tabelas-existentes-clientes").style.display = "block";
			document.getElementById("aux-adm-novos-clientes").style.display = "none";
			
			document.getElementById("adm-obras").style.display = "none";
			document.getElementById("adm-slides").style.display = "none";
			break;
		default:
			console.log("Opção OPC ADM inválida!");
			break;
	}
}

function config(){
	document.getElementById("config").style.display = "block";
	document.getElementById("principal").style.display = "none";
	document.getElementById("adm-slides").style.display = "none";
	document.getElementById("adm-obras").style.display = "none";
	document.getElementById("adm-clientes").style.display = "none";
}

// MANIPULAÇÃO DOS BOTÕES DENTRO DE CADA SEÇÃO DE GERENCIAMENTO
// TYPE => SLIDES, OBRAS, CLIENTES // OPC => CONSULTAR, CRIAR, ATUALIZAR, EXCLUIR
function adm_aux(type, opc){
	
	switch(type){ //SELECIONA A SEÇÃO QUE SERÁ GERENCIADA
		case 0: // SLIDES
	
			switch(opc){ //SELECIONA O BOTAO QUE FOI ACIONADO
				case 0: //Consultar Slides
					document.getElementById("adm-tabelas-existentes-slides").style.display = "block";
					document.getElementById("aux-adm-novos-slides").style.display = "none";
					document.getElementById("aux-adm-up-slides").style.display = "none";
					break;
				case 1: //Novos Slides
					document.getElementById("adm-tabelas-existentes-slides").style.display = "none";
					document.getElementById("aux-adm-up-slides").style.display = "none";
					document.getElementById("aux-adm-novos-slides").style.display = "block";
					break;
				case 2: //Atualizar Slides
					document.getElementById("adm-tabelas-existentes-slides").style.display = "none";
					document.getElementById("aux-adm-novos-slides").style.display = "none";
					document.getElementById("aux-adm-up-slides").style.display = "block";
					break;
				case 3: //Deletar Slides
					let text = "Você confirma a eliminação da tabela selecionada?"
					if (confirm(text) == true){
						alert("você excluiu a tabela");
					} else {
						alert("você cancelou a operação");
					}
					break;
				default:
					console.log("Opção OPC ADM-AUX inválida!");
					break;
			}
	
			break;
		case 1: //OBRAS

			switch(opc){ //SELECIONA O BOTAO QUE FOI ACIONADO
				case 0: //Consultar Obras
					document.getElementById("adm-tabelas-existentes-obras").style.display = "block";
					document.getElementById("aux-adm-novas-obras").style.display = "none";
					document.getElementById("aux-adm-up-obras").style.display = "none";
					break;
				case 1: //Novas Obras
					document.getElementById("adm-tabelas-existentes-obras").style.display = "none";
					document.getElementById("aux-adm-up-obras").style.display = "none";
					document.getElementById("aux-adm-novas-obras").style.display = "block";
					break;
				case 2: //Atualizar Obras
					document.getElementById("adm-tabelas-existentes-obras").style.display = "none";
					document.getElementById("aux-adm-novas-obras").style.display = "none";
					document.getElementById("aux-adm-up-obras").style.display = "block";
					break;
				case 3: //Deletar Obras
					let text = "Você confirma a eliminação da tabela selecionada?"
					if (confirm(text) == true){
						alert("você excluiu a tabela");
					} else {
						alert("você cancelou a operação");
					}
					break;
				default:
					console.log("Opção OPC ADM-AUX inválida!");
					break;
			}
		
			break;
		case 2: //CLIENTES

			switch(opc){ //SELECIONA O BOTAO QUE FOI ACIONADO
				case 0: //Consultar Clientes
					document.getElementById("adm-tabelas-existentes-clientes").style.display = "block";
					document.getElementById("aux-adm-novos-clientes").style.display = "none";
					document.getElementById("aux-adm-up-clientes").style.display = "none";
					break;
				case 1: //Novas Clientes
					document.getElementById("adm-tabelas-existentes-clientes").style.display = "none";
					document.getElementById("aux-adm-up-clientes").style.display = "none";
					document.getElementById("aux-adm-novos-clientes").style.display = "block";
					break;
				case 2: //Atualizar Clientes
					document.getElementById("adm-tabelas-existentes-clientes").style.display = "none";
					document.getElementById("aux-adm-novos-clientes").style.display = "none";
					document.getElementById("aux-adm-up-clientes").style.display = "block";
					break;
				case 3: //Deletar Clientes
					let text = "Você confirma a eliminação da tabela selecionada?"
					if (confirm(text) == true){
						alert("você excluiu a tabela");
					} else {
						alert("você cancelou a operação");
					}
					break;
				default:
					console.log("Opção OPC inválida!");
					break;
			}
			
			break;
		
		default:
			console.log("Opção TYPE inválida!");
			break;
	}
}

/*
function teste(){
	var elemento_Pai = document.getElementById("adm-tabelas-existentes-slides");
	var titulo = document.createElement('h1');
	var texto  = document.createTextNode("Um título qualquer");
	titulo.appendChild(texto);
	elemento_Pai.appendChild(titulo);
}*/